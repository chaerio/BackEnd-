package com.book45.domain;

import lombok.Data;

@Data
public class MemberOrderCancelDTO {

   private String id;
   private String orderNum;
   
}